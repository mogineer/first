

  function stoiconeReveal() {
    var x = document.getElementById("stoic-one");
    if (x.innerHTML === "“The happiness of your life depends upon the quality of your thoughts.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“The happiness of your life depends upon the quality of your thoughts.”";
    }
  }

  function stoictwoReveal() {
    var x = document.getElementById("stoic-two");
    if (x.innerHTML === "“The first step towards getting somewhere is to decide you're not going to stay where you are.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“The first step towards getting somewhere is to decide you're not going to stay where you are.”";
    }
  }

  function stoicthreeReveal() {
    var x = document.getElementById("stoic-three");
    if (x.innerHTML === "“We are more often frightened than hurt; and we suffer more in imagination than in reality.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“We are more often frightened than hurt; and we suffer more in imagination than in reality.”";
    }
  }

  function stoicfourReveal() {
    var x = document.getElementById("stoic-four");
    if (x.innerHTML === "“We are more often frightened than hurt; and we suffer more in imagination than in reality.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“We are more often frightened than hurt; and we suffer more in imagination than in reality.”";
    }
  }

  function stoicfiveReveal() {
    var x = document.getElementById("stoic-five");
    if (x.innerHTML === "“All that is necessary for evil to triumph is for good men to do nothing.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“All that is necessary for evil to triumph is for good men to do nothing.”";
    }
  }



  function epiconeReveal() {
    var x = document.getElementById("epic-one");
    if (x.innerHTML === "“Not what we have but what we enjoy constitutes our abundance.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“Not what we have but what we enjoy constitutes our abundance.”";
    }
  }

  function epictwoReveal() {
    var x = document.getElementById("epic-two");
    if (x.innerHTML === "“It is impossible for a man to learn what he thinks he already knows.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“It is impossible for a man to learn what he thinks he already knows.”";
    }
  }

  function epicthreeReveal() {
    var x = document.getElementById("epic-three");
    if (x.innerHTML === "“He who is not contented with what he has, would not be contented with what he would like to have.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“He who is not contented with what he has, would not be contented with what he would like to have.”";
    }
  }

  function epicfourReveal() {
    var x = document.getElementById("epic-four");
    if (x.innerHTML === "“The secret of happiness, you see, is not found in seeking more, but in developing the capacity to enjoy less.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“The secret of happiness, you see, is not found in seeking more, but in developing the capacity to enjoy less.”";
    }
  }

  function epicfiveReveal() {
    var x = document.getElementById("epic-five");
    if (x.innerHTML === "“Pleasure is the first good, not the only good.”") {
      x.innerHTML = "";
    } else {
      x.innerHTML = "“Pleasure is the first good, not the only good.”";
    }
  }
